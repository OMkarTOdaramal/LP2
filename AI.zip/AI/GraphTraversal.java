import java.util.*;

public class GraphTraversal {
    static void dfs(List<Integer>[] graph, int node, boolean[] visited) {
        visited[node] = true;
        System.out.print(node + " ");
        for (int neighbor : graph[node]) {
            if (!visited[neighbor]) {
                dfs(graph, neighbor, visited);
            }
        }
    }

    static void bfs(List<Integer>[] graph, int start) {
        Queue<Integer> queue = new LinkedList<>();
        boolean[] visited = new boolean[graph.length];

        queue.offer(start);
        visited[start] = true;

        while (!queue.isEmpty()) {
            int node = queue.poll();
            System.out.print(node + " ");
            for (int neighbor : graph[node]) {
                if (!visited[neighbor]) {
                    queue.offer(neighbor);
                    visited[neighbor] = true;
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of nodes: ");
        int n = scanner.nextInt();

        List<Integer>[] graph = new List[n];
        for (int i = 0; i < n; i++) {
            graph[i] = new ArrayList<>();
        }

        System.out.println("Enter the edges (node1 node2), enter -1 to stop:");
        while (true) {
            int node1 = scanner.nextInt();
            if (node1 == -1) break;
            int node2 = scanner.nextInt();
            graph[node1].add(node2);
        }

        System.out.println("DFS traversal:");
        boolean[] visitedDFS = new boolean[n];
        dfs(graph, 0, visitedDFS); // Start DFS from node 0

        System.out.println("\nBFS traversal:");
        bfs(graph, 0); // Start BFS from node 0

        scanner.close();
    }
}

/* Output
 Enter the number of nodes: 6
Enter the edges (node1 node2), enter -1 to stop:
0 1
0 2
1 3
1 4
2 4
3 5
4 5
-1
DFS traversal:
0 1 3 5 4 2
BFS traversal:
0 1 2 3 4 5
 */