import java.util.Scanner;

public class SimpleChatbot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Hello! I'm a simple chatbot. How can I help you today?");
        System.out.println("Type 'bye' to end the conversation.");

        String userInput;
        do {
            System.out.print("You: ");
            userInput = scanner.nextLine();

            // Bot's responses based on user input
            if (userInput.equalsIgnoreCase("hello")) {
                System.out.println("Bot: Hi there!");
            } else if (userInput.equalsIgnoreCase("how are you")) {
                System.out.println("Bot: I'm just a computer program, but thanks for asking!");
            } else if (userInput.equalsIgnoreCase("bye")) {
                System.out.println("Bot: Goodbye! Have a great day!");
            } else {
                System.out.println("Bot: Sorry, I didn't understand that.");
            }

        } while (!userInput.equalsIgnoreCase("bye"));

        // Display farewell message before terminating
        System.out.println("Bot: Conversation ended. Goodbye!");
        scanner.close();
    }
}
