import java.util.*;

public class PrimsAlgorithm {
    static class Edge {
        int source, dest, weight;

        Edge(int source, int dest, int weight) {
            this.source = source;
            this.dest = dest;
            this.weight = weight;
        }
    }

    static List<Edge> primMST(List<List<Edge>> graph) {
        int V = graph.size();
        boolean[] visited = new boolean[V];
        List<Edge> MST = new ArrayList<>();
        PriorityQueue<Edge> minHeap = new PriorityQueue<>(Comparator.comparingInt(edge -> edge.weight));

        minHeap.addAll(graph.get(0));
        visited[0] = true;

        while (!minHeap.isEmpty()) {
            Edge edge = minHeap.poll();
            if (visited[edge.dest]) continue;
            visited[edge.dest] = true;
            MST.add(edge);
            minHeap.addAll(graph.get(edge.dest));
        }

        return MST;
    }

    public static void main(String[] args) {
        int V = 5;
        List<List<Edge>> graph = new ArrayList<>();
        for (int i = 0; i < V; i++) {
            graph.add(new ArrayList<>());
        }

        // Adding edges to the graph
        graph.get(0).add(new Edge(0, 1, 2));
        graph.get(0).add(new Edge(0, 3, 6));
        graph.get(1).add(new Edge(1, 0, 2));
        graph.get(1).add(new Edge(1, 2, 3));
        graph.get(1).add(new Edge(1, 3, 8));
        graph.get(1).add(new Edge(1, 4, 5));
        graph.get(2).add(new Edge(2, 1, 3));
        graph.get(2).add(new Edge(2, 4, 7));
        graph.get(3).add(new Edge(3, 0, 6));
        graph.get(3).add(new Edge(3, 1, 8));
        graph.get(3).add(new Edge(3, 4, 9));
        graph.get(4).add(new Edge(4, 1, 5));
        graph.get(4).add(new Edge(4, 2, 7));
        graph.get(4).add(new Edge(4, 3, 9));

        List<Edge> MST = primMST(graph);
        System.out.println("Edges of Minimum Spanning Tree:");
        for (Edge edge : MST) {
            System.out.println(edge.source + " - " + edge.dest + ": " + edge.weight);
        }
    }
}
