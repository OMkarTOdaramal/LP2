import java.util.Scanner;

public class ColumnerTransposition {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input plaintext
        System.out.print("Enter the plaintext: ");
        String plaintext = scanner.nextLine().toUpperCase();

        // Input key (order of columns)
        System.out.print("Enter the key (order of columns): ");
        String key = scanner.nextLine();

        // Encrypt the plaintext
        String ciphertext = encrypt(plaintext, key);
        System.out.println("Encrypted Text: " + ciphertext);

        scanner.close();
    }

    public static String encrypt(String plaintext, String key) {
        // Remove spaces from the key
        key = key.replaceAll("\\s", "");

        // Calculate the number of columns
        int numCols = key.length();

        // Calculate the number of rows
        int numRows = (int) Math.ceil((double) plaintext.length() / numCols);

        // Create a 2D array to represent the grid
        char[][] grid = new char[numRows][numCols];

        // Fill the grid with the plaintext characters
        int index = 0;
        for (int col = 0; col < numCols; col++) {
            for (int row = 0; row < numRows; row++) {
                if (index < plaintext.length()) {
                    grid[row][col] = plaintext.charAt(index++);
                } else {
                    // If the plaintext is shorter than the grid, fill with 'X'
                    grid[row][col] = 'X';
                }
            }
        }

        // Encrypt the plaintext based on the column order given by the key
        StringBuilder ciphertext = new StringBuilder();
        for (int i = 0; i < key.length(); i++) {
            char columnChar = key.charAt(i);
            int columnIndex = columnChar - '1'; // Convert char to index

            // Append characters from the specified column to the ciphertext
            for (int row = 0; row < numRows; row++) {
                ciphertext.append(grid[row][columnIndex]);
            }
        }

        return ciphertext.toString();
    }
}
