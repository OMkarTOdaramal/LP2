public class ANDXOR {
    public static void main(String[] args) {
        // Input string
        String input = "Hello World";

        // Perform AND operation with 127
        String andResult = bitwiseAND(input, 127);
        System.out.println("AND Result: " + andResult);

        // Perform XOR operation with 127
        String xorResult = bitwiseXOR(input, 127);
        System.out.println("XOR Result: " + xorResult);
    }

    // Method to perform bitwise AND operation
    public static String bitwiseAND(String input, int value) {
        StringBuilder result = new StringBuilder();
        for (char c : input.toCharArray()) {
            result.append((char) (c & value));
        }
        return result.toString();
    }

    // Method to perform bitwise XOR operation
    public static String bitwiseXOR(String input, int value) {
        StringBuilder result = new StringBuilder();
        for (char c : input.toCharArray()) {
            result.append((char) (c ^ value));
        }
        return result.toString();
    }
}
