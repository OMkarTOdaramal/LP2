import java.util.Scanner;

public class RailFenceCipher {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input plaintext
        System.out.print("Enter the plaintext: ");
        String plaintext = scanner.nextLine().toUpperCase();

        // Input number of rails
        System.out.print("Enter the number of rails: ");
        int numRails = scanner.nextInt();

        // Encrypt the plaintext
        String ciphertext = encrypt(plaintext, numRails);
        System.out.println("Encrypted Text: " + ciphertext);

        scanner.close();
    }

    public static String encrypt(String plaintext, int numRails) {
        // Initialize an array of StringBuilder to represent each rail
        StringBuilder[] rails = new StringBuilder[numRails];
        for (int i = 0; i < numRails; i++) {
            rails[i] = new StringBuilder();
        }

        // Fill the rails with the plaintext characters
        int railIndex = 0;
        boolean down = true; // Direction indicator: true for down, false for up
        for (char c : plaintext.toCharArray()) {
            rails[railIndex].append(c);
            // Move to the next rail based on the direction
            if (down) {
                railIndex++;
            } else {
                railIndex--;
            }
            // Change direction when reaching the top or bottom rail
            if (railIndex == 0 || railIndex == numRails - 1) {
                down = !down;
            }
        }

        // Concatenate characters from all rails to form the ciphertext
        StringBuilder ciphertext = new StringBuilder();
        for (StringBuilder rail : rails) {
            ciphertext.append(rail);
        }
        return ciphertext.toString();
    }
}
