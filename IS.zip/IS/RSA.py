import math

# Step 1: Choose two distinct prime numbers p and q
p = 61
q = 53

# Step 2: Compute n
n = p * q
print("n =", n)

# Step 3: Compute Euler's totient function (phi)
phi = (p - 1) * (q - 1)
print("phi =", phi)

# Step 4: Choose e (public key)
e = 17  # Typically a small prime number
print("e =", e)

# Step 5: Compute d (private key)
def modinv(a, m):
    """Compute the modular multiplicative inverse of a modulo m."""
    g, x, _ = egcd(a, m)
    if g != 1:
        raise Exception('Modular inverse does not exist')
    return x % m

def egcd(a, b):
    """Extended Euclidean algorithm."""
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)

d = modinv(e, phi)
print("d =", d)

# Public and private key pair
public_key = (e, n)
private_key = (d, n)
print("Public key:", public_key)
print("Private key:", private_key)

# Plain text message
msg = 42
print("Original message:", msg)

# Encryption
C = pow(msg, e, n)
print("Encrypted message:", C)

# Decryption
M = pow(C, d, n)
print("Decrypted message:", M)
